
$(document).ready(function(){
    /*Arrow Effect*/
    var $Scroll_arrow = $(".Scrolling");
      $(window).scroll(function () {
          console.log($(this).scrollTop());
        if ($(this).scrollTop() >= 500) {
            $Scroll_arrow.show();
        } else {
            $Scroll_arrow.hide();
        }     
    });
        $Scroll_arrow.click(function(){
            $("html,body").animate({
                scrollTop : 0
            },1200);
        });
    
    //Load WebPage
$(window).load(function () {
    "use strict";

    //hide spinner
    $(".Loader .sk-folding-cube").fadeOut(2000, function () {
        //show HomePage
        $("body").css("overflow", "auto");
        //hider section with it's color
        $(this).parent().fadeOut(1000, function () {});
    });
});

});
    //Go To Link
 var $Master = $('#Master');
    $Master.click(function(){
        $("body").animate({
            scrollTop: 1440
        }, 1200);
    });
    
     var $Message = $('#Message');
    $Message.click(function(){
        $("body").animate({
            scrollTop: 949
        }, 1200);
    });